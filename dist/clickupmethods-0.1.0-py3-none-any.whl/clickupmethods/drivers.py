from clickupmethods.start import *

update_weekly_goals()
update_song_count()
update_song_artists_count()
